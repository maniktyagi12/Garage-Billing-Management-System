🧾 Garage Billing System (Command-Line Based)
This is a simple command-line based Garage Billing System developed in Java. It allows users to manage garage service records, calculate bills, and generate basic invoices directly from the terminal. The system handles customer details, vehicle services, and charges efficiently without any graphical interface.

✨ Features
Add customer and vehicle details

Select and manage services offered

Auto-calculate total bill with taxes (if any)

Generate and display invoice in terminal

Menu-driven and easy-to-use CLI interface

🛠️ Tech Stack
Language: Java

Interface: Command-Line Interface (CLI)

No external libraries used

📌 Note
This project is built for learning and demonstration purposes. It does not include any GUI and works entirely within the terminal.
