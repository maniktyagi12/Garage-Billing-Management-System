public class Car {
    private String carNumber;
    private String model;

    public Car(String model, String carNumber) {
        this.model = model;
        this.carNumber = carNumber;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public String getModel() {
        return model;
    }
}
