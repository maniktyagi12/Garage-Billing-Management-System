import java.util.Scanner;

public class GarageMain {
    public static void main(String[] args) {
        GarageService gs = new GarageService();
        Scanner sc = new Scanner(System.in);
        System.out.println("--------Healthy Car Service Center--------");
        while (true) {

            System.out.println("1. Add Customer");
            System.out.println("2. Create Invoice");
            System.out.println("3. Exit");
            System.out.print("Enter your Choice : ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter Customer Name : ");
                    String name = sc.next();
                    System.out.print("Enter Phone number : ");
                    String phone = sc.next();
                    System.out.print("Enter Car Number : ");
                    String carNum = sc.next();
                    System.out.print("Enter car Model : ");
                    String model = sc.next();
                    gs.addCustomer(name, phone, carNum, model);
                    break;
                case 2:
                    System.out.print("Enter car number : ");
                    String carNo = sc.next();
                    gs.CreateInvoice(carNo);
                    break;
                case 3:
                    System.out.println("Exiting.. Thankyou!");
                    sc.close();
                    return;
                default:
                    System.out.println("Enter a valid option-> ");
            }
        }
    }
}
