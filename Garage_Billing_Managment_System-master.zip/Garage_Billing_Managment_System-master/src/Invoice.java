import java.util.ArrayList;
import java.util.List;

public class Invoice {
    private Customer cosutmer;
    private List<Service> serviceList;
    private double totalamount;

    public Customer getCurstomer() {
        return cosutmer;
    }

    public List<Service> getServiceList() {
        return serviceList;
    }

    public double getTotalamount() {
        return totalamount;
    }

    public Invoice(Customer curstomer) {
        this.cosutmer = curstomer;
        this.serviceList = new ArrayList<>();
        this.totalamount = 0;
    }

    public void addService(Service service){
        serviceList.add(service);
        totalamount += service.getPrice();
    }

    public void printInvoice(){
        System.out.println("-----------------Invoice-----------------");
        System.out.print("Customer : " + cosutmer.getName() + " | Phone: " + cosutmer.getPhone());
        System.out.println("Car : " + cosutmer.getCar().getModel() + " | Number : " + cosutmer.getCar().getCarNumber());
        System.out.println("-----------------Services-----------------");
        for(Service service:serviceList){
            System.out.println("# "+ service.getName() + " : $" + service.getPrice());

        }
        System.out.println("------------------------------");
        System.out.println("Total Amount : " + totalamount );
        System.out.println("-----------------ThankYou-----------------");
    }
}
